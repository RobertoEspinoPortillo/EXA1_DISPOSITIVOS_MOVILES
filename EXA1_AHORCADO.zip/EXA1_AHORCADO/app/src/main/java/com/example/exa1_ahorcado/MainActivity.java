package com.example.exa1_ahorcado;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {
    //Variables Globales
    private String[] palabras = new String[]{
        "dinosaurio",
        "celular",
        "palomitas",
        "camiseta",
        "espejo",
        "sandia",
        "silla",
        "sarten",
        "sillon",
        "tequila"
    };

    private int num_intentos;
    private boolean xtream;
    private String letrasAdivinadas;
    private String palabra;

    //Elementos Graficos

    private TextView txtPalabra;
    private TextView txtNumLetras;
    private TextView txtIntentosRestantes;
    private EditText txtGuess;
    private RadioGroup rgNivel;
    private CheckBox cbXtreme;

    //Intentos
    private Intent goToScreen;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        txtPalabra = findViewById(R.id.lblPalabra);
        txtNumLetras = findViewById(R.id.lblNumLetras);
        txtIntentosRestantes = findViewById(R.id.lblIntentos);
        rgNivel = findViewById(R.id.rgNivel);
        cbXtreme = findViewById(R.id.cbXtreme);
        txtGuess = findViewById(R.id.txtGuess);


        iniciarValores();
    }

    @Override
    protected void onResume() {
        super.onResume();
        iniciarValores();
    }

    @Override
    protected void onRestart() {
        super.onRestart();
    }

    public void iniciarValores(View view){
        iniciarValores();
    }

    public void iniciarValores(){
        int index_palabra = (int)(Math.random() * (palabras.length - 1));
        palabra = palabras[index_palabra];

        RadioButton nivel_selected = findViewById(rgNivel.getCheckedRadioButtonId());
        if(nivel_selected.getText().toString().equals("Nivel Facil (6 intentos)")){
            num_intentos = 6;
        } else if (nivel_selected.getText().toString().equals("Nivel Medio (4 intentos)")){
            num_intentos = 4;
        } else{
            num_intentos = 2;
        }

        letrasAdivinadas = "";
        xtream = cbXtreme.isChecked();

        txtNumLetras.setText("" + palabra.length());
        txtIntentosRestantes.setText("" + num_intentos);
        mostrarLetras(palabra,letrasAdivinadas);
        txtGuess.setText("");
    }

    private void mostrarLetras(String palabra, String letrasAdivinadas) {
        String palabra_mostrar = "";
        char current_letter;
        for (int i = 0; i < palabra.length(); i++){
            current_letter = palabra.charAt(i);
            if(letrasAdivinadas.indexOf(current_letter) == -1){
                palabra_mostrar += "_";
            } else{
                palabra_mostrar += ("" + current_letter);
            }
            palabra_mostrar += " ";
        }

        txtPalabra.setText(palabra_mostrar);
    }

    public void guess(View view){
        guess();
    }

    public void guess(){
        String guess = txtGuess.getText().toString();

        if(guess.equals("")){
            Toast.makeText(this,"Texto invalido",Toast.LENGTH_SHORT).show();
        } else{
            if(guess.length() > 1){
                adivinarPalabra(guess);
            } else{
                adivinarLetra(guess);
            }
        }

        txtGuess.setText("");
    }

    private void adivinarLetra(String guess) {
        String vocales = "aeiou";

        if(palabra.indexOf(guess) == -1){
            num_intentos--;

        } else{
            if(xtream){
                if(vocales.indexOf(guess) != -1){
                    num_intentos--;
                }
            }
            letrasAdivinadas += guess;
            mostrarLetras(palabra,letrasAdivinadas);

        }
        txtIntentosRestantes.setText("" + num_intentos);

        if(adivinado()){
            goToScreen = new Intent(this,ScreenGanador.class);
            startActivity(goToScreen);
        } else if(num_intentos == 0){
            goToScreen = new Intent(this,PantallaPerdedor.class);
            startActivity(goToScreen);
        }
    }

    private boolean adivinado() {
        char current_letter;
        boolean all_match = true;
        for (int i = 0; i < palabra.length(); i++){
            current_letter = palabra.charAt(i);
            if(letrasAdivinadas.indexOf(current_letter) == -1){
                all_match = false;
                break;
            }
        }

        return all_match;
    }


    private void adivinarPalabra(String guess) {
        if(guess.equals(palabra)){
            goToScreen = new Intent(this,ScreenGanador.class);
            startActivity(goToScreen);
        } else{
            goToScreen = new Intent(this,PantallaPerdedor.class);
            startActivity(goToScreen);
        }
    }


}
